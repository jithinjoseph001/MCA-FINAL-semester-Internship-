"""policestaion URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.10/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.contrib import admin
from policestationapp.views import*
urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^$',home),
    url(r'^home',home,name="home"),
    url(r'^login/',login,name="login"),
    url(r'^registration/',registration,name="registration"),
    url(r'^home/',home,name="home"),
    url(r'^actionreg/',actionreg,name="actionreg"),
    url(r'^userlogin/',userlogin,name="userlogin"),
    url(r'^addlocation/',addlocation,name="addlocation"),
    url(r'^locationaction/',locationaction,name="locationaction"),
    url(r'^userhome/',userhome,name="userhome"),
    url(r'^adminhome/',adminhome,name="adminhome"),
    url(r'^reportcomplaints/',reportcomplaints,name="reportcomplaints"),
    url(r'^reportincidents/',reportincidents,name="reportincidents"),
    url(r'^incident/',incident,name="incident"),
    url(r'^complaint/',complaint,name="complaint"),
    url(r'^criminal/',criminal,name="criminal"),
    url(r'^addcriminal/',addcriminal,name="addcriminal"),
    url(r'^notification/',notification,name="notification"),
    url(r'^viewincident/',viewincident,name="viewincident"),
    url(r'^viewcomplaint/',viewcomplaint,name="viewcomplaint"),
    url(r'^viewlocation/',viewlocation,name="viewlocation"),
    
    url(r'^userviewcriminal/',userviewcriminal,name="userviewcriminal"),
    url(r'^replycomplaint/',replycomplaint,name="replycomplaint"),
    url(r'^complaintstatus/',complaintstatus,name="complaintstatus"),
    url(r'^viewnotification/',viewnotification,name="viewnotification"),
    url(r'^deletenotification/',deletenotification,name="deletenotification"),

    url(r'^locationdelete/',locationdelete,name="locationdelete"),
    url(r'^locationedit/',locationedit,name="locationedit"),
    url(r'^editnotification/',editnotification,name="editnotification"),
    url(r'^deleteincident/',deleteincident,name="deleteincident"),
    url(r'^policestation/',policestation,name="policestation"),
    url(r'^addstation/',addstation,name="addstation"),
    url(r'^userview/',userview,name="userview"),
    url(r'^stationview/',stationview,name="stationview"),
    url(r'^enterstation/',enterstation,name="enterstation"),
    url(r'^deleteuser/',deleteuser,name="deleteuser"),
    url(r'^edituser/',edituser,name="edituser"),
    url(r'^deletestation/',deletestation,name="deletestation"),
    url(r'^editstation/',editstation,name="editstation"),
    url(r'^selectlocation/',selectlocation,name="selectlocation"),  
    
    



]
