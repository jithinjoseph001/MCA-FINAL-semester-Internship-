from __future__ import unicode_literals

from django.db import models

# Create your models here.
class registrationtable(models.Model):
    firstname=models.CharField(max_length=100)
    lastname=models.CharField(max_length=100)
    email=models.CharField(max_length=100)
    phoneno=models.CharField(max_length=100)
    logid=models.IntegerField(default=0)
    role=models.CharField(max_length=200,default='user')
    address=models.CharField(max_length=200,default='address')

class logintable(models.Model):
    logid=models.IntegerField(primary_key=True)
    username=models.CharField(max_length=100)
    password=models.CharField(max_length=100)
    role=models.CharField(max_length=100)
    
class locationtable(models.Model):
    location=models.CharField(max_length=100)
    des=models.CharField(max_length=100)
    logid=models.IntegerField(default='0')

class incidentreporttable(models.Model):
    title=models.CharField(max_length=200)
    location=models.CharField(max_length=200)
    description=models.CharField(max_length=200)
    dates=models.CharField(max_length=200)

class complaintreporttable(models.Model):
    title=models.CharField(max_length=200)
    complaintant=models.CharField(max_length=200)
    address=models.CharField(max_length=200)
    place=models.CharField(max_length=200)
    complaintdescription=models.CharField(max_length=200)
    dateofcomplaint=models.CharField(max_length=200)
    status=models.CharField(max_length=200)
    reply=models.CharField(max_length=200,default='0')
    replydate=models.CharField(max_length=200,default='0')
    userid=models.CharField(max_length=200,default='0')
    stationid=models.IntegerField(default=0)

class criminaltable(models.Model):
    casetype=models.CharField(max_length=200)
    name=models.CharField(max_length=200)
    crimenumber=models.CharField(max_length=200)
    criminaldesc=models.CharField(max_length=200)
    crimedate=models.CharField(max_length=200)
    casedesc=models.CharField(max_length=200)
    status=models.CharField(max_length=200)
    image=models.CharField(max_length=200)
    logid=models.IntegerField(default='0')

class notificationtable(models.Model):
    notification=models.CharField(max_length=200)
    logid=models.IntegerField(default='0')
    
