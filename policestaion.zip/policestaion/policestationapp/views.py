from django.shortcuts import render
from models import *
from django.core import serializers
import json
from django.http import HttpResponse,JsonResponse
from django.core.files.storage import FileSystemStorage
from django.db.models import Avg, Max, Min, Sum
# Create your views here.
def home(request):
    return render(request,"index.html",{})
def login(request):
    return render(request,"login.html",{})
def registration(request):
    return render(request,"registration.html",{})
def userhome(request):
    obj=notificationtable.objects.all()
    return render(request,'userhome.html',{'detail':obj})
def policestation(request):
    return render(request,'policehome.html',{})
def adminhome(request):
    return render(request,'adminhome.html',{})
def actionreg(request):
    fn=request.POST.get("firstN")
    ln=request.POST.get("lastN")
    email=request.POST.get("email")
    phone=request.POST.get("phone")
    un=request.POST.get("username")
    pa=request.POST.get("password")
    address=request.POST.get("address")
    print "pa",pa
    pas=pa.encode('base64','strict')
    role="user"
    logtb=logintable(username=un,password=pas,role=role)
    logtb.save()
    ob=logintable.objects.all().aggregate(Max('logid'))
    print ob
    logid=ob['logid__max']
    print "logid",logid
    obj=registrationtable(firstname=fn,lastname=ln,email=email,phoneno=phone,logid=logid,role=role,address=address)
    obj.save()
   
    return HttpResponse("<script>alert('You Are Registered Successfully');window.location.href='/login/'</script>")

def userlogin(request):
    
   username=request.POST.get("username")
   password=request.POST.get("password")
   pas=password.encode('base64','strict')
   if username=="admin" and password=="admin":
        return HttpResponse("<script>alert('Successfull Login');window.location.href='/adminhome/'</script>")
   else:
       print "username",username
       print "password",password
       obj=logintable.objects.filter(username=username,password=pas)
       count=obj.count()
       print count
       if count==1:
           obj1=logintable.objects.get(username=username,password=pas)
           role=obj1.role
           print "role",role
           request.session['logid']=obj1.logid
           if role=="user":
                return HttpResponse("<script>alert('Successfull Login');window.location.href='/userhome/'</script>")
           elif role=="police":
                return HttpResponse("<script>alert('Successfull Login');window.location.href='/policestation/'</script>")

           else:         
           
                return HttpResponse("<script>alert('Invalid Login');window.location.href='/registration/'</script>")
       else:
           return HttpResponse("<script>alert('Invalid Login');window.location.href='/registration/'</script>") 
                  
   ###admin part

def addstation(request):
    return render(request,'addstations.html',{})

def userview(request):
    obj=registrationtable.objects.filter(role="user")
    return render(request,'adminviewusers.html',{'detail':obj})

def stationview(request):
    obj=registrationtable.objects.filter(role="police")
    return render(request,'adminviewstations.html',{'detail':obj})

def enterstation(request):
    print "enter station"
    name=request.POST.get("name")
    email=request.POST.get("email")
    phone=request.POST.get("phone")
    address=request.POST.get("address")
    username=request.POST.get("username")
    pa=request.POST.get("password")
    pas=pa.encode('base64','strict')
    print "name",name
    print "email",email
    print "phone",phone
    print "address",address
    print "username",username
    print pa
    print "password",type(pa)
    print "pass",pas
    role="police"
    logtb=logintable(username=username,password=pas,role=role)
    logtb.save()
    ob=logintable.objects.all().aggregate(Max('logid'))
    print ob
    logid=ob['logid__max']
    print "logid",logid
    obj=registrationtable(firstname=name,lastname="station",email=email,phoneno=phone,logid=logid,role=role,address=address)
    obj.save()
    return HttpResponse("<script>alert('Added Successfully');window.location.href='/addstation/'</script>")

def deleteuser(request):
    id1=request.GET.get("id")
    print id1
    ob=registrationtable.objects.get(id=id1)
    print "ob",ob
    
    logid=ob.logid
    ob1=logintable.objects.get(logid=logid)
    ob.delete()
    ob1.delete()
    return HttpResponse("Deleted Successfully")

def edituser(request):
    id1=request.GET.get("id")
    name=request.GET.get("name")
    email=request.GET.get("email")
    phone=request.GET.get("phone")
    address=request.GET.get("address")
    print "id1",id1
    print "name",name
    print "email",email
    print "phone",phone
    print "address",address
    obj=registrationtable.objects.get(id=id1)
    obj.firstname=name
    obj.email=email
    obj.phoneno=phone
    obj.address=address
    print "dsfvmb"
    obj.save()
    
    return HttpResponse("Edited Successfully")


def editstation(request):
    id1=request.GET.get("id")
    name=request.GET.get("name")
    email=request.GET.get("email")
    phone=request.GET.get("phone")
    address=request.GET.get("address")
    print "id1",id1
    print "name",name
    print "email",email
    print "phone",phone
    print "address",address
    obj=registrationtable.objects.get(id=id1)
    obj.firstname=name
    obj.email=email
    obj.phoneno=phone
    obj.address=address
    print "dsfvmb"
    obj.save()
    
    return HttpResponse("Edited Successfully")

def deletestation(request):
    id1=request.GET.get("id")
    print id1
    ob=registrationtable.objects.get(id=id1)
    print "ob",ob
    
    logid=ob.logid
    ob1=logintable.objects.get(logid=logid)
    ob.delete()
    ob1.delete()
    return HttpResponse("Deleted Successfully")
    

def reportcomplaints(request):
    obj=registrationtable.objects.filter(role="police")
    return render(request,"usercomplaint.html",{'police':obj})

def addlocation(request):
    return render(request,"addlocation.html",{})


def locationaction(request):
    logid=request.session["logid"]
    fn=request.POST.get("location")
    ln=request.POST.get("des")
    print fn,ln
    obj=locationtable(location=fn,des=ln,logid=logid)
    obj.save()
    return HttpResponse("<script>alert('Successfully Added The Location');window.location.href='/addlocation/'</script>")
   
    return render(request,"addlocation.html",{})


def reportincidents(request):
    print "incident"
    return render(request,"reportincident.html",{})
def incident(request):
    title=request.POST.get("title")
    location=request.POST.get("location")
    description=request.POST.get("description")
    datetimes=request.POST.get("datetime")
    s=datetimes.split('T')
    date=s[0]+" "+s[1]
    print date
    print "title",title
    print "location",location
    print "description",description
    print "datetime",datetimes
    obj=incidentreporttable(title=title,location=location,description=description,dates=date)
    obj.save()
    return HttpResponse("<script>alert('Successfully Reported The Incident');window.location.href='/reportincidents/'</script>")
    
def complaint(request):
    title=request.POST.get("title")
    complaintant=request.POST.get("complaintant")
    address=request.POST.get("address")
    station=request.POST.get("police")
    place=request.POST.get("place")
    complaintdescription=request.POST.get("casedescription")
    dateofcomplaint=request.POST.get("dateofcomplaint")
    status="pending"
    s=dateofcomplaint.split('T')
    date=s[0]+" "+s[1]
    reply="Reply"
    replydate="Reply Date"
    userid=request.session["logid"]
    print date
    print "title",title
    print "complaintant",complaintant
    print "address",address
    print "place",place
    print "casedescription",complaintdescription
    print "dateofcomplaint",dateofcomplaint
    obj=complaintreporttable(title=title,complaintant=complaintant,address=address,place=place,complaintdescription=complaintdescription,dateofcomplaint=date,status=status,reply=reply,replydate=replydate,userid=userid,stationid=station)
    obj.save()
    return HttpResponse("<script>alert('Successfully Reported The Complaint');window.location.href='/reportcomplaints/'</script>")
    
def criminal(request):
    return render(request,'addcriminals.html',{})

def addcriminal(request):
    casetype=request.POST.get("casetype")
    name=request.POST.get("name")
    crimenumber=request.POST.get("crimenumber")
    criminaldesc=request.POST.get("criminaldesc")
    datetimes=request.POST.get("datetimes")
    casedesc=request.POST.get("casedesc")
    status=request.POST.get("status")
    image=request.FILES["image"]
    print "casetype",casetype
    print "name",name
    print "crimenumber",crimenumber
    print "criminaldesc",criminaldesc
    print "datetimes",datetimes
    print "casedesc",casedesc
    print "status",status
    print "image",image
    logid=request.session["logid"]
    fs=FileSystemStorage("policestationapp/static/criminalimage")
    fs.save(image.name,image)
    obj=criminaltable(casetype=casetype,name=name,crimenumber=crimenumber,criminaldesc=criminaldesc,crimedate=datetimes,casedesc=casedesc,status=status,image=image,logid=logid)
    obj.save()
    return HttpResponse("<script>alert('Successfully Added The Criminal');window.location.href='/criminal/'</script>")

def notification(request):
    logid=request.session["logid"]
    notification=request.POST.get("notification")
    obj=notificationtable(notification=notification,logid=logid)
    obj.save()
    return HttpResponse("<script>alert('Notification Added');window.location.href='/addlocation/'</script>")

def viewincident(request):
    obj=incidentreporttable.objects.all()
    return render(request,'viewincident.html',{'detail':obj})

def viewcomplaint(request):
    station=request.session["logid"]
    obj=complaintreporttable.objects.filter(stationid=station)
    return render(request,'viewcomplaint.html',{'detail':obj})

def userviewcriminal(request):
    obj=criminaltable.objects.all()
    return render(request,'viewcriminal.html',{'detail':obj})

def replycomplaint(request):
    id1=request.GET.get("id")
    reply=request.GET.get("reply")
    replydate=request.GET.get("replydate")
    status=request.GET.get("status")
    print "reply",reply
    print "replydate",replydate
    print "status",status
    obj=complaintreporttable.objects.get(id=id1)
    obj.reply=reply
    obj.replydate=replydate
    obj.status=status
    obj.save()
    return HttpResponse("Replied")

def complaintstatus(request):
    print "shdbcds"
    userid=request.session["logid"]
    print "userid",userid
    obj=complaintreporttable.objects.filter(userid=userid)
    if obj:
        
        return render(request,'complaintstatus.html',{'detail':obj})
    else:
        return HttpResponse("<script>alert('No Data Available');window.location.href='/userhome/'</script>")

def viewlocation(request):
    logid=request.session["logid"]
    obj=locationtable.objects.filter(logid=logid)
    return render(request,'adminviewlocation.html',{'detail':obj})

def viewnotification(request):
    logid=request.session["logid"]
    obj=notificationtable.objects.filter(logid=logid)
    return render(request,'adminviewnotification.html',{'detail':obj})

def deletenotification(request):
    id1=request.GET.get("id")
    obj=notificationtable.objects.get(id=id1)
    obj.delete()
    print "id",id1
    return HttpResponse("Deleted Successfully")


def locationdelete(request):
    id1=request.GET.get("id")
    obj=locationtable.objects.get(id=id1)
    obj.delete()
    print "id",id1
    return HttpResponse("Deleted Successfully")

def locationedit(request):
    id1=request.GET.get("id")
    location=request.GET.get("location")
    des=request.GET.get("des")
    print "id1",id1
    print "location",location
    print "des",des
    obj=locationtable.objects.get(id=id1)
    obj.location=location
    obj.des=des
    obj.save()
    return HttpResponse("Edited Successfully")

def editnotification(request):
    id1=request.GET.get("id")
    notification=request.GET.get("notification")
    print "id1",id1
    print "notification",notification
    obj=notificationtable.objects.get(id=id1)
    obj.notification=notification
    obj.save()
    return HttpResponse("Edited Successfully")

def deleteincident(request):
    id1=request.GET.get("id")
    obj=incidentreporttable.objects.get(id=id1)
    obj.delete()
    print "id",id1
    return HttpResponse("Deleted Successfully")

##user
def selectlocation(request):
    loc=request.GET.get("id")
    print "id",loc
    data={}
    obj=locationtable.objects.filter(logid=loc)
    ab=serializers.serialize("json",obj)
    data['detail']=json.loads(ab)
    print data
    return JsonResponse(data,safe=False)
    

